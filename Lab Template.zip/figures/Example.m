% Example MATLAB code
function y = example(x)
    % This is a simple example function
    y = x.^2 + 2*x + 1;
    
    % Plot the result
    figure;
    plot(x, y);
    xlabel('x');
    ylabel('y');
    title('Example Function');
end
